/**
*size:火焰大小（必须）
*speed：火焰摆动速度（可选），default is 3.0
*color：火焰颜色（可选）,火焰最外层颜色大致为RGB的值（0到1）+2.0，default is THREE.Vector3(2.5, 2.0, 1.5)
*
*/

THREE.Fire = function (size, speed, color) {
    var firePlane, material, uniforms;
        
    uniforms = {
		time: { type: "f", value: 1.0 },
        speed: {type: "f", value: 3.0},
        color: {type: "v3", value: new THREE.Vector3(2.5, 2.0, 1.5)}
	};

	material = new THREE.ShaderMaterial( {
		uniforms: uniforms,
		vertexShader: THREE.ShaderFire.candelFire.vertexShader,
		fragmentShader: THREE.ShaderFire.candelFire.fragmentShader
    } );
    
    firePlane = new THREE.Mesh( new THREE.PlaneGeometry(size, size), material);
    firePlane.visible = true;
    
    if(typeof speed !== "undefined") {
        uniforms.speed.value = speed;
    }
    
    if(typeof color !== "undefined") {
        uniforms.color.value.copy(color); 
    }
    
    firePlane.time = uniforms.time;
    
    return firePlane;
};

THREE.ShaderFire = {
    candelFire : {
        vertexShader : [
            
			"varying vec2 vUv;",

			"void main()",
			"{",
				"vUv = uv;",
				"vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );",
				"gl_Position = projectionMatrix * mvPosition;",
			"}"

        ].join("\n"),
        fragmentShader : [
            
            "#ifdef GL_ES",
            "precision mediump float;",
            "#endif",

            "// Paremeters --------------------------",

            "const float height = 5.0;",
            "const float size = 10.0;",
            "const float noiseSize = 2.0;",
            "const float noiseStrength = 0.15;",
            "const int noiseDepth = 3;",
            "const vec2 defaultPosition = vec2(0.0, -0.75);",

            "//--------------------------------------",

            "uniform vec3 color;",
            "uniform float speed;",
            "uniform float time;",
            "varying vec2 vUv;",

            "vec4 mod289(vec4 x)",
            "{",
              "return x - floor(x * (1.0 / 289.0)) * 289.0;",
            "}",

            "vec4 permute(vec4 x)",
            "{",
              "return mod289(((x*34.0)+1.0)*x);",
            "}",

            "vec4 taylorInvSqrt(vec4 r)",
            "{",
              "return 1.79284291400159 - 0.85373472095314 * r;",
            "}",

            "vec2 fade(vec2 t) {",
             " return t*t*t*(t*(t*6.0-15.0)+10.0);",
            "}",

            "float cnoise(vec2 P)",
            "{",
              "vec4 Pi = floor(P.xyxy) + vec4(0.0, 0.0, 1.0, 1.0);",
              "vec4 Pf = fract(P.xyxy) - vec4(0.0, 0.0, 1.0, 1.0);",
              "Pi = mod289(Pi);",
              "vec4 ix = Pi.xzxz;",
              "vec4 iy = Pi.yyww;",
              "vec4 fx = Pf.xzxz;",
              "vec4 fy = Pf.yyww;",

              "vec4 i = permute(permute(ix) + iy);",

              "vec4 gx = fract(i * (1.0 / 41.0)) * 2.0 - 1.0 ;",
              "vec4 gy = abs(gx) - 0.5 ;",
              "vec4 tx = floor(gx + 0.5);",
              "gx = gx - tx;",

              "vec2 g00 = vec2(gx.x,gy.x);",
              "vec2 g10 = vec2(gx.y,gy.y);",
              "vec2 g01 = vec2(gx.z,gy.z);",
              "vec2 g11 = vec2(gx.w,gy.w);",

              "vec4 norm = taylorInvSqrt(vec4(dot(g00, g00), dot(g01, g01), dot(g10, g10), dot(g11, g11)));",
              "g00 *= norm.x;",
              "g01 *= norm.y;",
              "g10 *= norm.z;",
              "g11 *= norm.w;",

              "float n00 = dot(g00, vec2(fx.x, fy.x));",
              "float n10 = dot(g10, vec2(fx.y, fy.y));",
              "float n01 = dot(g01, vec2(fx.z, fy.z));",
              "float n11 = dot(g11, vec2(fx.w, fy.w));",

              "vec2 fade_xy = fade(Pf.xy);",
              "vec2 n_x = mix(vec2(n00, n01), vec2(n10, n11), fade_xy.x);",
              "float n_xy = mix(n_x.x, n_x.y, fade_xy.y);",
              "return 2.3 * n_xy;",
            "}",

            "void main( void ) {",
                "vec2 position = defaultPosition;",
                
                "vec2 fragment =  -1.0 + 2.0 * vUv;",
             
                "vec2 coord;",
                "if (fragment.y > position.y) {",
                    "coord = vec2(fragment.x, position.y + (fragment.y - position.y) / height);",
                "} else {",
                   "coord = fragment.xy;",
                "}",
                "float dist = distance(position, coord);",
               
                "vec2 noisePosition = noiseSize * (fragment.xy - position) - vec2(0.0, speed * time);",
                "float noise = 0.0;",
                "for (int i = 0; i < noiseDepth; i++) {",
                    "noise += cnoise(noisePosition * pow(2.0, float(i)));",
                "}",
                
                "gl_FragColor = vec4(mix(-size * dist, noise, noiseStrength) + color, mix(-size * dist, noise, noiseStrength) + 2.5);",
                "}"
                
        ].join("\n")
    }
};